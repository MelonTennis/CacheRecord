#### Traces & Plots

----------

*p in S_LRU means the weight of LRU in cache, set before running trace

*p in ARC means weight of LRU in cache, adjust by ARC after running trace

*Rreference means the total number of reference to cache

*Unique means the unique block reference input file

*HitRate = hit count/ total count(referNum)

*when comparing with policy, p in S_LRU is set to 0.5

--------

**Random**

Trace: random_mini, 64 reference, 60 unique

<img src="./plots/Screen Shot 2017-07-20 at 1.14.37 AM.png" width="450" height="300"/>

**Policy - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 2.19.26 AM.png" width="450" height="300"/>

ARC, S_LRU have same result, LRU, LFU, MRU have same result for random reference. 

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 2.19.33 AM.png" width="450" height="300"/>

No influence of LRU percent in S_LRU.

---

**Sequene**

Trace: sequence_medium_16, 512 reference, 16 unique, loop size = 16 

<img src="./plots/Screen Shot 2017-07-20 at 7.19.35 AM.png" width="450" height="300"/>

**Policy - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 7.26.29 AM.png" width="450" height="300"/>

LRU, S_LRU, ARC have same result, when cache size < loop size, hit rate == 0, when cache size > loop size, hit rate ~ 1.

LFU, MRU have similar result, when cache size < loop size, hit rate increase as cache size approach loop size .

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 7.50.07 AM.png" width="450" height="300"/>

No influence on hit rate.

----------

**Change of Pattern**

Trace: changePattern_small, 280 reference, 122 unique

<img src="./plots/Screen Shot 2017-07-20 at 7.55.15 AM.png" width="450" height="300"/>

**Policy - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 8.10.15 AM.png" width="450" height="300"/>

MRU worst, LFU, ARC, S_LRU similar, LRU little worse than them.

**p_ARC - cacheSize**

<img src="./plots/Screen Shot 2017-07-20 at 8.12.50 AM.png" width="450" height="300"/>

When cache size is less, *p* in ARC tend to be higher.

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 8.24.11 AM.png" width="450" height="300"/>

When cache size is higher, *p* does not have influence on hit rate, when cache size is smaller, after some threshold value, as *p* increasing , hit rate decreasing. The threshould of *p* increases as cache size increases.  *p* in ARC is not the best value for S_LRU, but is not a bad one.

**refTime - HitRate**

Cache size = 32

<img src="./plots/Screen Shot 2017-07-20 at 9.23.50 AM.png" width="450" height="300"/>

Because the change of pattern. 

Trace: changePattern_small2, 448 reference, 183 unique

<img src="./plots/Screen Shot 2017-07-20 at 8.29.13 AM.png" width="450" height="300"/>

**Policy - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 9.29.01 AM.png" width="450" height="300"/>

 LRU, ARC, S_LRU similar, LFU, MRU similar

**p_ARC - cacheSize**
<img src="./plots/Screen Shot 2017-07-20 at 9.29.34 AM.png" width="450" height="300"/>

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 9.33.05 AM.png" width="450" height="300"/>

Lower *p* in S_LRU seems have good hit rate for high cache size, and *p* generate from ARC is acceptable though not optimal. 

**Reference time - HitRate**

cache size = 64

<img src="./plots/Screen Shot 2017-07-20 at 9.40.13 AM.png" width="450" height="300"/>

Depends on trace pattern.

Trace: changePattern_medium, 3072 reference, 1506 unique

<img src="./plots/Screen Shot 2017-07-20 at 9.47.17 AM.png" width="450" height="300"/>

Ugly

**Policy - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 9.48.10 AM.png" width="450" height="300"/>

**p_ARC - cacheSize**

<img src="./plots/Screen Shot 2017-07-20 at 9.48.20 AM.png" width="450" height="300"/>

Higher when cache size is less. 

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 9.52.55 AM.png" width="450" height="300"/>

Lower *p* in S_LRU seems have good hit rate for high cache size, and *p* generate from ARC is acceptable though not optimal. 

**ReferenceTime - HitRate**

cache size = 128

<img src="./plots/Screen Shot 2017-07-20 at 9.57.03 AM.png" width="450" height="300"/>

Depends on trace pattern.

-------

**OLTP**

Trace: WebSearch1.spc, 1055448 reference, 480446 unique

plot [0:2048]

<img src="./plots/Screen Shot 2017-07-20 at 10.00.52 AM.png" width="450" height="300"/>

**Policy - HitRate**

experiment [0, 4096]

<img src="./plots/Screen Shot 2017-07-20 at 10.29.12 AM.png" width="450" height="300"/>

ARC, S_LRU behave like LRU but much quicker. Hit rate is hold by cache size.

**p_ARC - cacheSize**

<img src="./plots/Screen Shot 2017-07-20 at 10.17.08 AM.png" width="450" height="300"/>

All zero.

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 10.33.21 AM.png" width="450" height="300"/>

0 is not optimal.

**ReferenceTime - hitRate**

Cache size = 2048

<img src="./plots/Screen Shot 2017-07-20 at 10.50.14 AM.png" width="450" height="300"/>

Trace: Financial2.spc, 3699194 reference, 296073 unique

plot[0:2048]

<img src="./plots/Screen Shot 2017-07-20 at 10.38.23 AM.png" width="450" height="300"/>

**Policy - HitRate**

experiment[0:2048]

<img src="./plots/Screen Shot 2017-07-20 at 10.54.00 AM.png" width="450" height="300"/>

**p_ARC - cacheSize**

<img src="./plots/Screen Shot 2017-07-20 at 10.54.59 AM.png" width="450" height="300"/>

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 10.58.40 AM.png" width="450" height="300"/>

**ReferenceTime - HitRate**

cacheSize = 2048

<img src="./plots/Screen Shot 2017-07-20 at 11.02.13 AM.png" width="450" height="300"/>

Trace: Financial1.spc, 5334987 reference, 710908 unique

Plot [0, 4096]

<img src="./plots/Screen Shot 2017-07-20 at 2.01.42 PM.png" width="450" height="300"/>

**Policy - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 2.00.05 PM.png" width="450" height="300"/>

**p_ARC - cacheSize**

<img src="./plots/Screen Shot 2017-07-20 at 2.00.10 PM.png" width="450" height="300"/>

**p_S_LRU - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 2.00.15 PM.png" width="450" height="300"/>

**ReferenceTime - HitRate**

<img src="./plots/Screen Shot 2017-07-20 at 2.00.20 PM.png" width="450" height="300"/>

----------

**OTLP whole set**

Trace: Financial2.spc,  3699194 reference, 296073 unique

<img src="./plots/Screen Shot 2017-07-21 at 8.55.14 AM.png" width="450" height="300"/>

<img src="./plots/Screen Shot 2017-07-21 at 8.55.26 AM.png" width="450" height="300"/>

Trace: WebSearch1.spc, 1055448 reference, 480446 unique

<img src="./plots/Screen Shot 2017-07-21 at 8.55.32 AM.png" width="450" height="300"/>

<img src="./plots/Screen Shot 2017-07-21 at 8.55.38 AM.png" width="450" height="300"/>

-----------

**Conclusion**

ARC and S_LRU have best performance, ARC need space for ghost entry contains information, which is the same size as cache. S_LRU needs tuning parameter, which can be choose from [0, 1], one between [0, 0.5] may be a good choice.